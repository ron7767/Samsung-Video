# Samsung Video Classic / Ultra — proyecto Android nativo

Dos variantes Android instalables: `classicDebug` y `ultraDebug`.

## Base implementada
- Biblioteca local mediante MediaStore y permiso de Android.
- Pestañas Videos y Folders.
- Búsqueda por nombre y carpeta.
- Orden por fecha o nombre.
- Reproductor integrado en la parte superior: al tocar un video empieza a reproducirse y la biblioteca permanece debajo.
- Motor Media3/ExoPlayer y servicio MediaSession como base para reproducción externa.
- Dos identidades visuales independientes.

## Todavía pendiente de desarrollar y probar
Miniaturas reales, cuadrícula visual avanzada, reproductor completo independiente, gestos de brillo/volumen/zoom, velocidades, pistas de audio, subtítulos, gestión de archivos, HDR/360/DRM, PiP compartiendo la misma sesión, controles de reproducción en segundo plano y enlace con ajustes Samsung/Dolby. No se deben considerar terminadas hasta implementarlas y probarlas en un Galaxy real.

## Compilación
Con Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17 y SDK Android 35:
`gradle assembleClassicDebug assembleUltraDebug`
