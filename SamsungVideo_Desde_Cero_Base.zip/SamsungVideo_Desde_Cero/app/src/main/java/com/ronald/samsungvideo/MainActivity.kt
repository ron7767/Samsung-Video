package com.ronald.samsungvideo

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.TextWatcher
import android.text.Editable
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.util.Locale

data class Clip(val uri: android.net.Uri, val name: String, val folder: String, val duration: Long, val size: Long, val date: Long) {
 fun time() = "%d:%02d".format(duration / 60000, (duration / 1000) % 60)
}
class MainActivity : AppCompatActivity() {
 private lateinit var root: LinearLayout; private lateinit var rows: LinearLayout; private lateinit var search: EditText; private lateinit var playerView: PlayerView
 private lateinit var player: ExoPlayer; private var clips = listOf<Clip>(); private var folders = false; private var grid = false; private var newest = true
 private val ask = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) load() else empty("Permite el acceso a videos para ver tu biblioteca.") }
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); player = ExoPlayer.Builder(this).build(); ui(); val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE; if (ContextCompat.checkSelfPermission(this,p)==PackageManager.PERMISSION_GRANTED) load() else ask.launch(p) }
 private fun ui() {
  val ultra = BuildConfig.EDITION == "ULTRA"; val bg = if (ultra) 0xFF11131A.toInt() else 0xFF080808.toInt(); val accent = if (ultra) 0xFF83B4FF.toInt() else 0xFFE0E0E0.toInt()
  root = LinearLayout(this).apply { orientation=1; setBackgroundColor(bg) }
  root.addView(TextView(this).apply { text=if(ultra) "SAMSUNG VIDEO ULTRA" else "Samsung Video"; textSize=22f; setTextColor(-1); setPadding(20,22,12,14) })
  search=EditText(this).apply { hint="Buscar videos"; setSingleLine(); setTextColor(-1); setHintTextColor(0xFFAAAAAA.toInt()) }; root.addView(search)
  val bar=LinearLayout(this); bar.addView(btn("Videos",accent){folders=false;render()},LinearLayout.LayoutParams(0,-2,1f)); bar.addView(btn("Folders",accent){folders=true;render()},LinearLayout.LayoutParams(0,-2,1f)); bar.addView(btn("Ordenar",accent){newest=!newest;render()},LinearLayout.LayoutParams(0,-2,1f)); bar.addView(btn("Vista",accent){grid=!grid;render()},LinearLayout.LayoutParams(0,-2,1f)); root.addView(bar)
  playerView=PlayerView(this).apply { player=this@MainActivity.player; useController=true }; root.addView(playerView,LinearLayout.LayoutParams(-1,dp(205)))
  val scroll=ScrollView(this); rows=LinearLayout(this).apply { orientation=1; setPadding(8,4,8,20) }; scroll.addView(rows); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
  search.addTextChangedListener(object:TextWatcher { override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}; override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render()}; override fun afterTextChanged(e:Editable?){} })
 }
 private fun btn(t:String,c:Int,action:()->Unit)=Button(this).apply { text=t; textSize=11f; isAllCaps=false; setTextColor(c); setOnClickListener{action()} }
 private fun load() { val out=mutableListOf<Clip>(); val collection=MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL); val cols=arrayOf(MediaStore.Video.Media._ID,MediaStore.Video.Media.DISPLAY_NAME,MediaStore.Video.Media.DURATION,MediaStore.Video.Media.SIZE,MediaStore.Video.Media.DATE_ADDED,MediaStore.Video.Media.BUCKET_DISPLAY_NAME); contentResolver.query(collection,cols,null,null,"${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c -> while(c.moveToNext()){ val id=c.getLong(0); out.add(Clip(ContentUris.withAppendedId(collection,id),c.getString(1)?:"Video",c.getString(5)?:"Otros",c.getLong(2),c.getLong(3),c.getLong(4))) } }; clips=out; render() }
 private fun render() { if(!::rows.isInitialized)return; rows.removeAllViews(); val q=search.text.toString().lowercase(Locale.getDefault()); val data=clips.filter{it.name.lowercase().contains(q)||it.folder.lowercase().contains(q)}.let{if(newest)it.sortedByDescending(Clip::date) else it.sortedBy{v->v.name.lowercase()}}
  if(folders){ data.groupBy{it.folder}.toSortedMap().forEach{(name,items)-> rows.addView(TextView(this).apply{text="📁  $name  ·  ${items.size} videos";textSize=16f;setTextColor(-1);setPadding(16,20,12,20);setOnClickListener{folders=false;search.setText(name)}}); line() }; return }
  if(data.isEmpty()){empty(if(clips.isEmpty())"No se encontraron videos en el dispositivo." else "No hay resultados.");return}
  data.forEach { v -> val card=LinearLayout(this).apply{orientation=1;setPadding(12,14,12,14);setOnClickListener{player.setMediaItem(MediaItem.fromUri(v.uri));player.prepare();player.play()}}; card.addView(TextView(this).apply{text="▶  ${v.name}";textSize=15f;setTextColor(-1);maxLines=2}); card.addView(TextView(this).apply{text="${v.time()}  ·  ${v.size/1_000_000} MB  ·  ${v.folder}";textSize=11f;setTextColor(0xFFAAAAAA.toInt())}); rows.addView(card);line() }
 }
 private fun empty(s:String){rows.removeAllViews();rows.addView(TextView(this).apply{text=s;setTextColor(-1);setPadding(20,30,20,20)})}
 private fun line(){rows.addView(View(this).apply{setBackgroundColor(0xFF333333.toInt())},LinearLayout.LayoutParams(-1,dp(1)))}
 private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
 override fun onDestroy(){player.release();super.onDestroy()}
}
