# Samsung Video — proyecto Android nativo

Incluye biblioteca MediaStore, miniaturas, búsqueda, orden básico, pestaña de carpetas, mini reproductor y pantalla completa compartiendo una instancia ExoPlayer, cola secuencial, aleatorio, repetición, velocidades 0.5x–2x y PiP básico.

Compilación: JDK 17, Android SDK 35, Gradle 8.9; ejecutar `gradle assembleDebug`.

IMPORTANTE: este proyecto fuente no está certificado sin errores ni probado en Galaxy S25 Ultra. Debe compilarse y probarse. Aún no implementa gestos de doble toque/deslizamiento, control de brillo/volumen por gestos, pellizco, operaciones de archivos, selector avanzado de pistas, servicio de reproducción persistente, lectura de metadatos HDR/360/DRM/Hyperlapse ni integración directa con Dolby Atmos/ecualizador Samsung. PiP depende del soporte Android/One UI. La pestaña Carpetas muestra un elemento representativo por carpeta, no un explorador completo. No se debe considerar una versión final hasta implementar y probar esos puntos.
