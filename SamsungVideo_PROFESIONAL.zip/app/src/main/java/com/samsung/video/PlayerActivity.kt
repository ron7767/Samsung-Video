package com.samsung.video
import android.app.PictureInPictureParams
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.View
import android.widget.Button
import android.widget.PopupMenu
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Player
import androidx.media3.common.PlaybackParameters
import androidx.media3.ui.PlayerView
class PlayerActivity:AppCompatActivity(){
 private val app get()=application as SamsungVideoApp
 private val speeds=floatArrayOf(.5f,.8f,1f,1.25f,1.5f,2f)
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContentView(R.layout.activity_player)
  window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
  findViewById<PlayerView>(R.id.fullPlayer).player=app.player
  findViewById<Button>(R.id.backToLibrary).setOnClickListener{finish()}
  findViewById<Button>(R.id.shuffle).setOnClickListener{app.shuffle=!app.shuffle;app.player.shuffleModeEnabled=app.shuffle;(it as Button).text=if(app.shuffle)"Aleatorio: sí" else "Aleatorio"}
  findViewById<Button>(R.id.repeat).setOnClickListener{app.repeatMode=when(app.repeatMode){Player.REPEAT_MODE_OFF->Player.REPEAT_MODE_ALL;Player.REPEAT_MODE_ALL->Player.REPEAT_MODE_ONE;else->Player.REPEAT_MODE_OFF};app.player.repeatMode=app.repeatMode;(it as Button).text=when(app.repeatMode){Player.REPEAT_MODE_ALL->"Repetir todo";Player.REPEAT_MODE_ONE->"Repetir uno";else->"Repetir: no"}}
  findViewById<Button>(R.id.speed).setOnClickListener{view->val menu=PopupMenu(this,view);speeds.forEach{menu.menu.add("${it}×")};menu.setOnMenuItemClickListener{item->val x=item.title.toString().removeSuffix("×").toFloatOrNull()?:1f;app.player.setPlaybackParameters(PlaybackParameters(x));findViewById<Button>(R.id.speed).text="${x}×";true};menu.show()}
 }
 override fun onUserLeaveHint(){if(Build.VERSION.SDK_INT>=26&&app.player.isPlaying)enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16,9)).build());super.onUserLeaveHint()}
 override fun onStop(){findViewById<PlayerView>(R.id.fullPlayer).player=null;super.onStop()}
}
