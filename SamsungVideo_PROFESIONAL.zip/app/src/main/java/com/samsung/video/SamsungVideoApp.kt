package com.samsung.video
import android.app.Application
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
class SamsungVideoApp: Application() {
 lateinit var player: ExoPlayer; private set
 val queue=mutableListOf<VideoItem>(); var shuffle=false; var repeatMode=Player.REPEAT_MODE_OFF; var currentTitle=""
 override fun onCreate(){ super.onCreate(); player=ExoPlayer.Builder(this).build() }
}
