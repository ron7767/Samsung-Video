package com.samsung.video
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
class VideoAdapter(private var items:List<VideoItem>,private val click:(VideoItem)->Unit):RecyclerView.Adapter<VideoAdapter.Holder>(){
 class Holder(v:View):RecyclerView.ViewHolder(v){val thumb:ImageView=v.findViewById(R.id.thumbnail);val title:TextView=v.findViewById(R.id.videoTitle);val detail:TextView=v.findViewById(R.id.videoDetail)}
 override fun onCreateViewHolder(p:ViewGroup,t:Int)=Holder(LayoutInflater.from(p.context).inflate(R.layout.item_video,p,false))
 override fun getItemCount()=items.size
 override fun onBindViewHolder(h:Holder,pos:Int){val v=items[pos];h.title.text=v.name;h.detail.text="${v.durationText()} · ${v.sizeText()} · ${v.folder}"
  try{val b:Bitmap?=if(Build.VERSION.SDK_INT>=29)h.itemView.context.contentResolver.loadThumbnail(v.uri,android.util.Size(480,270),null) else MediaStore.Video.Thumbnails.getThumbnail(h.itemView.context.contentResolver,v.id,MediaStore.Video.Thumbnails.MINI_KIND,null);h.thumb.setImageBitmap(b)}catch(_:Exception){h.thumb.setImageResource(R.drawable.ic_app)}
  h.itemView.setOnClickListener{click(v)}
 }
 fun submit(v:List<VideoItem>){items=v;notifyDataSetChanged()}
}
