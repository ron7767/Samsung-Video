package com.samsung.video
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
class MainActivity:AppCompatActivity(){
 private val app get()=application as SamsungVideoApp
 private lateinit var adapter:VideoAdapter
 private var all=listOf<VideoItem>();private var folders=false
 private val permission=registerForActivityResult(ActivityResultContracts.RequestPermission()){if(it)load() else Toast.makeText(this,"Permite acceso a videos para mostrar la biblioteca",Toast.LENGTH_LONG).show()}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContentView(R.layout.activity_main)
  val list=findViewById<RecyclerView>(R.id.videoList);list.layoutManager=LinearLayoutManager(this);adapter=VideoAdapter(emptyList()){play(it)};list.adapter=adapter
  findViewById<Button>(R.id.videosTab).setOnClickListener{folders=false;render()}
  findViewById<Button>(R.id.foldersTab).setOnClickListener{folders=true;render()}
  findViewById<Button>(R.id.expand).setOnClickListener{startActivity(Intent(this,PlayerActivity::class.java))}
  findViewById<Button>(R.id.closeMini).setOnClickListener{app.player.stop();app.player.clearMediaItems();app.queue.clear();findViewById<View>(R.id.miniPanel).visibility=View.GONE}
  findViewById<EditText>(R.id.search).addTextChangedListener(SimpleTextWatcher{render(it)})
  val sp=findViewById<Spinner>(R.id.sortSpinner);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Más recientes","Nombre","Duración","Tamaño"))
  sp.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){render()}}
  val perm=if(Build.VERSION.SDK_INT>=33)Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
  if(ContextCompat.checkSelfPermission(this,perm)==PackageManager.PERMISSION_GRANTED)load() else permission.launch(perm)
 }
 private fun load(){all=VideoRepository.load(this);render()}
 private fun render(q:String=findViewById<EditText>(R.id.search).text.toString()){val sp=findViewById<Spinner>(R.id.sortSpinner);val f=all.filter{it.name.contains(q,true)||it.folder.contains(q,true)}
  val sorted=when(sp.selectedItemPosition){1->f.sortedBy{it.name.lowercase()};2->f.sortedByDescending{it.duration};3->f.sortedByDescending{it.size};else->f.sortedByDescending{it.date}}
  adapter.submit(if(folders)sorted.groupBy{it.folder}.values.mapNotNull{it.firstOrNull()} else sorted)
 }
 private fun play(item:VideoItem){val ordered=all.sortedByDescending{it.date};app.queue.clear();app.queue.addAll(ordered);val index=ordered.indexOfFirst{it.id==item.id}.coerceAtLeast(0)
  app.player.setMediaItems(ordered.map{MediaItem.fromUri(it.uri)},index,0L);app.player.prepare();app.player.playWhenReady=true;app.currentTitle=item.name
  findViewById<TextView>(R.id.miniTitle).text=item.name;findViewById<View>(R.id.miniPanel).visibility=View.VISIBLE;findViewById<PlayerView>(R.id.miniPlayer).player=app.player
 }
 override fun onStart(){super.onStart();if(::adapter.isInitialized&&app.player.mediaItemCount>0){findViewById<View>(R.id.miniPanel).visibility=View.VISIBLE;findViewById<PlayerView>(R.id.miniPlayer).player=app.player;findViewById<TextView>(R.id.miniTitle).text=app.currentTitle}}
 override fun onStop(){if(::adapter.isInitialized)findViewById<PlayerView>(R.id.miniPlayer).player=null;super.onStop()}
}
