# Samsung Video

Proyecto Android nativo en Kotlin para una única aplicación y un único APK.

## Identidad visual
- Tema oscuro negro/grafito con acentos azul eléctrico y plateado.
- Icono propio y pantalla de inicio Android SplashScreen.
- Biblioteca con cuadrícula/lista, búsqueda, carpetas y ordenamiento.
- El reproductor de vista previa está oculto al abrir. Al seleccionar un video aparece integrado en la parte superior; incluye botón X para cerrarlo y botón para abrir pantalla completa.

## Compilación
Abrir el proyecto en Android Studio y ejecutar `:app:assembleDebug`.
El APK de depuración se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Estado y límites
Esta entrega es una primera base funcional, no la aplicación final completa. Deben probarse la compilación y el comportamiento en el Galaxy S25 Ultra. Funciones avanzadas pendientes de implementar/verificar incluyen gestos completos de brillo/volumen/zoom, velocidad configurable, pistas/subtítulos, administración de archivos, PiP/segundo plano robusto, HDR/360/DRM y compatibilidad específica con funciones Samsung/Dolby. Dolby Atmos y ecualizador dependen del dispositivo y de las API disponibles; la app no puede garantizar activar funciones propietarias.
