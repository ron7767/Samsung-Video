package com.ronald.samsungvideo

import android.net.Uri
import java.util.concurrent.TimeUnit

data class VideoItem(
    val id: Long, val uri: Uri, val name: String, val duration: Long,
    val size: Long, val dateAdded: Long, val folder: String
) {
    fun durationText(): String {
        val total = TimeUnit.MILLISECONDS.toSeconds(duration)
        return "%d:%02d".format(total / 60, total % 60)
    }
    fun sizeText(): String = if (size >= 1_000_000_000) "%.2f GB".format(size / 1_000_000_000.0)
        else "%.1f MB".format(size / 1_000_000.0)
}
