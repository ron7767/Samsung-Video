package com.ronald.samsungvideo

import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.MotionEvent
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlin.math.abs

class PlayerActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    private var startX = 0f
    private var startY = 0f
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent.data ?: intent.getParcelableExtra<Uri>("video_uri") ?: run { finish(); return }
        player = ExoPlayer.Builder(this).build()
        val view = PlayerView(this).apply { player = this@PlayerActivity.player; useController = true }
        setContentView(FrameLayout(this).apply { addView(view, FrameLayout.LayoutParams(-1, -1)) })
        player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.play()
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX = event.x; startY = event.y; true }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - startX
                    val dy = event.y - startY
                    if (abs(dx) > dp(70) && abs(dx) > abs(dy)) {
                        player.seekTo((player.currentPosition + if (dx > 0) 5000 else -5000).coerceAtLeast(0))
                    }
                    true
                }
                else -> true
            }
        }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onUserLeaveHint() {
        if (Build.VERSION.SDK_INT >= 26) enterPictureInPictureMode(
            android.app.PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
    }
    override fun onDestroy() { player.release(); super.onDestroy() }
}
