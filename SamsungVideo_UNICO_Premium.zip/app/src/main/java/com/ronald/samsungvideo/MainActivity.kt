package com.ronald.samsungvideo

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.ThumbnailUtils
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var preview: PlayerView
    private lateinit var previewPanel: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var videos: List<VideoItem>
    private var foldersMode = false
    private var gridMode = true
    private var newestFirst = true
    private var activeVideo: VideoItem? = null
    private val thumbExecutor = Executors.newFixedThreadPool(2)

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) loadVideos() else showMessage("Activa el permiso de videos para mostrar tu biblioteca.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF070A10.toInt()
        window.navigationBarColor = 0xFF070A10.toInt()
        window.decorView.systemUiVisibility = 0
        player = ExoPlayer.Builder(this).build()
        buildUi()
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED) loadVideos() else permission.launch(p)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF080B12.toInt()) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(15), dp(20), dp(8)) }
        header.addView(TextView(this).apply { text = "SAMSUNG"; textSize = 11f; letterSpacing = .28f; setTextColor(0xFF65B9FF.toInt()) })
        header.addView(TextView(this).apply { text = "Video"; textSize = 30f; letterSpacing = .02f; setTextColor(0xFFF4F6FB.toInt()); setTypeface(null, android.graphics.Typeface.BOLD) })
        root.addView(header)

        search = EditText(this).apply {
            hint = "Buscar en tu biblioteca"; setSingleLine(true); textSize = 14f
            setTextColor(0xFFF4F6FB.toInt()); setHintTextColor(0xFF778195.toInt())
            background = rounded(0xFF151B27.toInt(), 18); setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(48)).apply { setMargins(dp(16), dp(4), dp(16), dp(12)) })

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), 0, dp(12), dp(10)) }
        tabs.addView(chip("Videos") { foldersMode = false; render() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        tabs.addView(chip("Carpetas") { foldersMode = true; render() }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(8) })
        tabs.addView(chip("Ordenar") { newestFirst = !newestFirst; render() }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(8) })
        tabs.addView(chip("Vista") { gridMode = !gridMode; render() }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(8) })
        root.addView(tabs)

        previewPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setPadding(dp(12), dp(8), dp(12), dp(10)); background = rounded(0xFF111827.toInt(), 20)
        }
        val previewHeader = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        previewHeader.addView(TextView(this).apply { text = "REPRODUCIENDO"; textSize = 10f; letterSpacing = .15f; setTextColor(0xFF72C5FF.toInt()) }, LinearLayout.LayoutParams(0, -2, 1f))
        previewHeader.addView(iconButton("×") { closePreview() })
        previewPanel.addView(previewHeader)
        preview = PlayerView(this).apply {
            useController = true; player = this@MainActivity.player
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        }
        previewPanel.addView(preview, LinearLayout.LayoutParams(-1, dp(190)))
        val expand = TextView(this).apply {
            text = "⛶   Abrir en pantalla completa"; gravity = Gravity.CENTER; textSize = 13f
            setTextColor(0xFFE8F3FF.toInt()); background = rounded(0xFF1B2B43.toInt(), 14); setPadding(8, dp(11), 8, dp(11))
            setOnClickListener { activeVideo?.let { v -> startActivity(Intent(this@MainActivity, PlayerActivity::class.java).setData(v.uri)) } }
        }
        previewPanel.addView(expand, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(previewPanel, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), 0, dp(12), dp(8)) })

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(28)) }
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        search.addTextChangedListener(SimpleTextWatcher { render() })
    }

    private fun chip(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 12f; setTextColor(0xFFDCE8F8.toInt())
        background = rounded(0xFF151E2D.toInt(), 15); setOnClickListener { action() }
    }
    private fun iconButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 25f; gravity = Gravity.CENTER; setTextColor(0xFFEAF3FF.toInt())
        setPadding(dp(10), 0, dp(10), 0); setOnClickListener { action() }
    }
    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), 0xFF26364C.toInt())
    }
    private fun loadVideos() { videos = VideoRepository(this).load(); render() }

    private fun render() {
        if (!::list.isInitialized || !::videos.isInitialized) return
        list.removeAllViews()
        val q = search.text?.toString()?.trim()?.lowercase(Locale.getDefault()).orEmpty()
        val filtered = videos.filter { it.name.lowercase().contains(q) || it.folder.lowercase().contains(q) }
            .let { if (newestFirst) it.sortedByDescending(VideoItem::dateAdded) else it.sortedBy { v -> v.name.lowercase() } }
        if (foldersMode) {
            filtered.groupBy { it.folder }.toSortedMap().forEach { (folder, items) ->
                val row = TextView(this).apply {
                    text = "▣    $folder\n       ${items.size} videos"; textSize = 15f; setTextColor(0xFFF1F5FC.toInt())
                    background = rounded(0xFF121A27.toInt(), 17); setPadding(dp(18), dp(18), dp(12), dp(18))
                    setOnClickListener { foldersMode = false; search.setText(folder); render() }
                }
                list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
            }
        } else if (filtered.isEmpty()) showMessage(if (videos.isEmpty()) "Todavía no hay videos disponibles." else "No encontramos resultados.")
        else if (gridMode) {
            filtered.chunked(2).forEach { pair ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                pair.forEach { row.addView(videoCard(it), LinearLayout.LayoutParams(0, -2, 1f).apply { if (pair.indexOf(it) == 1) leftMargin = dp(8) }) }
                if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f).apply { leftMargin = dp(8) })
                list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            }
        } else filtered.forEach { list.addView(videoCard(it)); list.addView(View(this), LinearLayout.LayoutParams(-1, dp(8))) }
    }

    private fun videoCard(v: VideoItem): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(0xFF151C29.toInt(), 17); clipToOutline = true }
        val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF202A39.toInt()) }
        card.addView(image, LinearLayout.LayoutParams(-1, dp(112)))
        thumbExecutor.execute {
            try {
                val bmp: Bitmap? = if (Build.VERSION.SDK_INT >= 29) contentResolver.loadThumbnail(v.uri, Size(480, 270), null)
                    else ThumbnailUtils.createVideoThumbnail(File(v.uri.path ?: "").absolutePath, MediaStore.Images.Thumbnails.MINI_KIND)
                if (bmp != null) runOnUiThread { image.setImageBitmap(bmp) }
            } catch (_: Exception) { }
        }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(9), dp(10), dp(10)) }
        info.addView(TextView(this).apply { text = v.name; textSize = 12f; maxLines = 2; setTextColor(0xFFF2F5FA.toInt()) })
        info.addView(TextView(this).apply { text = "${v.durationText()}  ·  ${v.sizeText()}"; textSize = 10f; setTextColor(0xFF9BA9BD.toInt()); setPadding(0, dp(5), 0, 0) })
        card.addView(info)
        card.setOnClickListener { playInPreview(v) }
        return card
    }
    private fun playInPreview(v: VideoItem) {
        activeVideo = v; previewPanel.visibility = View.VISIBLE
        player.setMediaItem(MediaItem.fromUri(v.uri)); player.prepare(); player.play()
        previewPanel.requestFocus()
    }
    private fun closePreview() { player.pause(); player.clearMediaItems(); activeVideo = null; previewPanel.visibility = View.GONE }
    private fun showMessage(message: String) {
        list.removeAllViews(); list.addView(TextView(this).apply { text = message; textSize = 14f; setTextColor(0xFFADB9CA.toInt()); setPadding(dp(12), dp(30), dp(12), dp(20)) })
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { thumbExecutor.shutdown(); if (isFinishing) player.release(); super.onDestroy() }
}
