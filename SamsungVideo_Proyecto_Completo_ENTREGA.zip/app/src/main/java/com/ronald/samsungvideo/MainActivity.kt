package com.ronald.samsungvideo

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PlayerView
    private lateinit var player: ExoPlayer
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private var videos = listOf<VideoItem>()
    private var foldersMode = false
    private var gridMode = false
    private var newestFirst = true

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) loadVideos() else showMessage("Permite el acceso a videos para mostrar tu biblioteca.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        buildUi()
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
                else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED) loadVideos()
        else permission.launch(p)
    }

    private fun buildUi() {
        val ultra = BuildConfig.EDITION == "ULTRA"
        val bg = if (ultra) 0xFF101116.toInt() else 0xFF080808.toInt()
        val accent = if (ultra) 0xFF79A9FF.toInt() else 0xFFBDBDBD.toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        root.addView(TextView(this).apply {
            text = if (ultra) "SAMSUNG VIDEO ULTRA" else "Samsung Video"
            textSize = if (ultra) 21f else 23f; setTextColor(-1); gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 22, 16, 14)
        })
        search = EditText(this).apply {
            hint = "Buscar videos"; setSingleLine(true); setTextColor(-1); setHintTextColor(0xFF999999.toInt())
            setPadding(18, 8, 18, 8)
        }
        root.addView(search)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabs.addView(button("Videos", accent) { foldersMode = false; render() }, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(button("Folders", accent) { foldersMode = true; render() }, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(button("Ordenar", accent) { newestFirst = !newestFirst; render() }, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(button("Cuadrícula/lista", accent) { gridMode = !gridMode; render() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(tabs)
        preview = PlayerView(this).apply { useController = true; player = this@MainActivity.player }
        root.addView(preview, LinearLayout.LayoutParams(-1, dp(205)))
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(10, 6, 10, 24) }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        search.addTextChangedListener(SimpleTextWatcher { render() })
    }

    private fun button(label: String, color: Int, click: () -> Unit) = Button(this).apply {
        text = label; textSize = 11f; setTextColor(color); isAllCaps = false
        setOnClickListener { click() }
    }
    private fun loadVideos() { videos = VideoRepository(this).load(); render() }

    private fun render() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val q = search.text?.toString()?.trim()?.lowercase(Locale.getDefault()).orEmpty()
        val filtered = videos.filter { it.name.lowercase().contains(q) || it.folder.lowercase().contains(q) }
            .let { if (newestFirst) it.sortedByDescending(VideoItem::dateAdded) else it.sortedBy { v -> v.name.lowercase() } }
        if (foldersMode) {
            filtered.groupBy { it.folder }.toSortedMap().forEach { (folder, items) ->
                list.addView(TextView(this).apply {
                    text = "📁  $folder   ·   ${items.size} videos"; textSize = 16f; setTextColor(-1)
                    setPadding(16, 20, 12, 20)
                    setOnClickListener { foldersMode = false; search.setText(folder); render() }
                })
                divider()
            }
        } else if (filtered.isEmpty()) showMessage(if (videos.isEmpty()) "No se encontraron videos." else "No hay resultados.")
        else if (gridMode) {
            var row: LinearLayout? = null
            filtered.forEachIndexed { index, video ->
                if (index % 2 == 0) { row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; list.addView(row) }
                row?.addView(videoCard(video), LinearLayout.LayoutParams(0, -2, 1f))
            }
        } else filtered.forEach { list.addView(videoCard(it)); divider() }
    }

    private fun videoCard(v: VideoItem): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(12, 13, 12, 13)
        addView(TextView(this@MainActivity).apply { text = "▶  ${v.name}"; textSize = 15f; setTextColor(-1); maxLines = 2 })
        addView(TextView(this@MainActivity).apply {
            text = "${v.durationText()} · ${v.sizeText()} · ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(v.dateAdded * 1000))}"
            textSize = 11f; setTextColor(0xFFAAAAAA.toInt())
        })
        setOnClickListener { player.setMediaItem(MediaItem.fromUri(v.uri)); player.prepare(); player.play() }
    }
    private fun showMessage(message: String) {
        if (!::list.isInitialized) return
        list.removeAllViews()
        list.addView(TextView(this).apply { text = message; textSize = 14f; setTextColor(-1); setPadding(20, 28, 20, 20) })
    }
    private fun divider() { list.addView(View(this).apply { setBackgroundColor(0xFF303030.toInt()) }, LinearLayout.LayoutParams(-1, dp(1))) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { if (isFinishing) player.release(); super.onDestroy() }
}
