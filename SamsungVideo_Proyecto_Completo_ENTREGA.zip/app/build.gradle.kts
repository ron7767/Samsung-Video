plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ronald.samsungvideo"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.ronald.samsungvideo"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
    flavorDimensions += "edition"
    productFlavors {
        create("classic") {
            dimension = "edition"
            applicationIdSuffix = ".classic"
            versionNameSuffix = "-classic"
            resValue("string", "app_name", "Samsung Video Classic")
            buildConfigField("String", "EDITION", "\"CLASSIC\"")
        }
        create("ultra") {
            dimension = "edition"
            applicationIdSuffix = ".ultra"
            versionNameSuffix = "-ultra"
            resValue("string", "app_name", "Samsung Video Ultra")
            buildConfigField("String", "EDITION", "\"ULTRA\"")
        }
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
}
