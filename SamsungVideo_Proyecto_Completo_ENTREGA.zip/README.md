# Samsung Video Classic y Ultra

Proyecto Android nativo Kotlin con dos variantes instalables: `classicDebug` y `ultraDebug`.

Esta es una base inicial, no la aplicación final. Incluye consulta de videos locales, biblioteca Videos/Folders, búsqueda, ordenamiento, lista/cuadrícula y reproducción integrada con Media3.

Pendiente de desarrollo y pruebas: miniaturas reales, gestos completos, velocidad, audio/subtítulos, HDR/360/DRM/metadatos, gestión de archivos, PiP robusto, sesión compartida con servicio de reproducción, integración de sonido Samsung y validación en dispositivo.
