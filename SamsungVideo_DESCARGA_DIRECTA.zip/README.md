# Samsung Video — proyecto nuevo

Proyecto Android nativo Kotlin creado desde cero. Incluye biblioteca MediaStore, mini reproductor y reproductor a pantalla completa que comparten una única instancia ExoPlayer, búsqueda, orden básico, selección de videos, cola secuencial, aleatorio y repetición.

## Compilación
Requiere JDK 17, Android SDK 35 y Gradle 8.9:
`gradle assembleDebug`

## Estado y límites
Esta es una base funcional inicial, no una certificación de ausencia de errores. Debe compilarse y probarse en un Galaxy S25 Ultra. La biblioteca usa permisos multimedia de Android. La pestaña Carpetas muestra un video representativo por carpeta en esta primera base. Funciones como gestos avanzados, mini ventana redimensionable, PiP, audio en segundo plano, operaciones de archivos, selección de pistas y metadatos HDR/360/DRM aún requieren implementación y pruebas posteriores. La compatibilidad Dolby Atmos/ecualizador Samsung depende de One UI y de las capacidades del dispositivo.
