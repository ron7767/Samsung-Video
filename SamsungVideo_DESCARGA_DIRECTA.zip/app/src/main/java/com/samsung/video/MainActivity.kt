package com.samsung.video

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.ui.PlayerView

class MainActivity : AppCompatActivity() {
    private val app get() = application as SamsungVideoApp
    private lateinit var adapter: VideoAdapter
    private var all = listOf<VideoItem>()
    private var foldersMode = false
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) loadVideos() else Toast.makeText(this, "Se necesita permiso para mostrar tus videos", Toast.LENGTH_LONG).show()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val list = findViewById<RecyclerView>(R.id.videoList)
        list.layoutManager = LinearLayoutManager(this)
        adapter = VideoAdapter(emptyList()) { index -> playAt(index) }
        list.adapter = adapter
        findViewById<Button>(R.id.videosTab).setOnClickListener { foldersMode = false; render() }
        findViewById<Button>(R.id.foldersTab).setOnClickListener { foldersMode = true; render() }
        findViewById<Button>(R.id.expand).setOnClickListener { startActivity(Intent(this, PlayerActivity::class.java)) }
        findViewById<Button>(R.id.closeMini).setOnClickListener {
            app.player.stop(); findViewById<View>(R.id.miniPanel).visibility = View.GONE
            app.queue.clear()
        }
        findViewById<EditText>(R.id.search).addTextChangedListener(SimpleTextWatcher { render(it) })
        val spinner = findViewById<Spinner>(R.id.sortSpinner)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Más recientes", "Nombre", "Duración", "Tamaño"))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { render() }
        }
        checkPermission()
    }
    private fun checkPermission() {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED) loadVideos()
        else permission.launch(p)
    }
    private fun loadVideos() { all = VideoRepository.load(this); render() }
    private fun render(query: String = findViewById<EditText>(R.id.search).text.toString()) {
        val spinner = findViewById<Spinner>(R.id.sortSpinner)
        val filtered = all.filter { it.name.contains(query, true) || it.folder.contains(query, true) }
        val sorted = when (spinner.selectedItemPosition) {
            1 -> filtered.sortedBy { it.name.lowercase() }
            2 -> filtered.sortedByDescending { it.duration }
            3 -> filtered.sortedByDescending { it.size }
            else -> filtered.sortedByDescending { it.date }
        }
        if (!foldersMode) adapter.submit(sorted)
        else {
            val unique = sorted.groupBy { it.folder }.values.mapNotNull { it.firstOrNull() }
            adapter.submit(unique)
        }
    }
    private fun playAt(index: Int) {
        val current = if (foldersMode) all.groupBy { it.folder }.values.mapNotNull { it.firstOrNull() } else
            all.sortedByDescending { it.date }
        if (index !in current.indices) return
        app.queue.clear(); app.queue.addAll(current)
        app.player.setMediaItems(current.map { MediaItem.fromUri(it.uri) }, index, 0L)
        app.player.prepare(); app.player.playWhenReady = true
        findViewById<TextView>(R.id.miniTitle).text = current[index].name
        findViewById<View>(R.id.miniPanel).visibility = View.VISIBLE
        val pv = findViewById<PlayerView>(R.id.miniPlayer)
        pv.player = app.player
    }
    override fun onStart() {
        super.onStart()
        if (::adapter.isInitialized && app.player.mediaItemCount > 0) {
            findViewById<View>(R.id.miniPanel).visibility = View.VISIBLE
            findViewById<PlayerView>(R.id.miniPlayer).player = app.player
            findViewById<TextView>(R.id.miniTitle).text = all.firstOrNull()?.name ?: "Reproduciendo"
        }
    }
    override fun onStop() {
        if (::adapter.isInitialized) findViewById<PlayerView>(R.id.miniPlayer).player = null
        super.onStop()
    }
}
