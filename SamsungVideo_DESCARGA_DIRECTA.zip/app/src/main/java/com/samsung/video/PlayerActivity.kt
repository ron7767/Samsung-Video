package com.samsung.video

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Player
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {
    private val app get() = application as SamsungVideoApp
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        findViewById<PlayerView>(R.id.fullPlayer).player = app.player
        findViewById<Button>(R.id.backToLibrary).setOnClickListener { finish() }
        findViewById<Button>(R.id.shuffle).setOnClickListener {
            app.shuffle = !app.shuffle
            app.player.shuffleModeEnabled = app.shuffle
            findViewById<Button>(R.id.shuffle).text = if (app.shuffle) "Aleatorio: sí" else "Aleatorio"
        }
        findViewById<Button>(R.id.repeat).setOnClickListener {
            app.repeatMode = when (app.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
            app.player.repeatMode = app.repeatMode
            findViewById<Button>(R.id.repeat).text = when (app.repeatMode) {
                Player.REPEAT_MODE_ALL -> "Repetir todo"
                Player.REPEAT_MODE_ONE -> "Repetir uno"
                else -> "Repetir: no"
            }
        }
    }
    override fun onStop() {
        findViewById<PlayerView>(R.id.fullPlayer).player = null
        super.onStop()
    }
}
