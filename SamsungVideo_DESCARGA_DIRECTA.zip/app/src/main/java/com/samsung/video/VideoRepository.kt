package com.samsung.video

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore

object VideoRepository {
    fun load(context: Context): List<VideoItem> {
        val result = mutableListOf<VideoItem>()
        val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED, MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        context.contentResolver.query(collection, projection, null, null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val duration = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val size = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val date = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val folder = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            while (c.moveToNext()) {
                val mediaId = c.getLong(id)
                result += VideoItem(mediaId, c.getString(name) ?: "Video",
                    ContentUris.withAppendedId(collection, mediaId), c.getLong(duration),
                    c.getLong(size), c.getLong(date), c.getString(folder) ?: "Otros")
            }
        }
        return result
    }
}
