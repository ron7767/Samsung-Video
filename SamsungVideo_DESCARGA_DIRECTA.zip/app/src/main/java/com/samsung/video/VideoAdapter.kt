package com.samsung.video

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.provider.MediaStore
import android.graphics.Bitmap
import android.os.Build

class VideoAdapter(
    private var items: List<VideoItem>,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<VideoAdapter.Holder>() {
    inner class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumbnail)
        val title: TextView = v.findViewById(R.id.videoTitle)
        val detail: TextView = v.findViewById(R.id.videoDetail)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_video, parent, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: Holder, position: Int) {
        val item = items[position]
        h.title.text = item.name
        h.detail.text = "${item.durationText()}  ·  ${item.sizeText()}  ·  ${item.folder}"
        try {
            val bitmap: Bitmap? = if (Build.VERSION.SDK_INT >= 29)
                h.itemView.context.contentResolver.loadThumbnail(item.uri, android.util.Size(480, 270), null)
            else MediaStore.Video.Thumbnails.getThumbnail(h.itemView.context.contentResolver,
                item.id, MediaStore.Video.Thumbnails.MINI_KIND, null)
            h.thumb.setImageBitmap(bitmap)
        } catch (_: Exception) { h.thumb.setImageResource(R.drawable.ic_app) }
        h.itemView.setOnClickListener { onClick(h.bindingAdapterPosition) }
    }
    fun submit(list: List<VideoItem>) { items = list; notifyDataSetChanged() }
}
