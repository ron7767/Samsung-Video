package com.samsung.video

import android.net.Uri

data class VideoItem(
    val id: Long,
    val name: String,
    val uri: Uri,
    val duration: Long,
    val size: Long,
    val date: Long,
    val folder: String
) {
    fun durationText(): String {
        val s = duration / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }
    fun sizeText(): String = if (size >= 1_000_000_000) "%.1f GB".format(size / 1_000_000_000.0)
        else "%.0f MB".format(size / 1_000_000.0)
}
