package com.samsung.video

import android.app.Application
import androidx.media3.exoplayer.ExoPlayer

class SamsungVideoApp : Application() {
    lateinit var player: ExoPlayer
        private set
    val queue = mutableListOf<VideoItem>()
    var shuffle = false
    var repeatMode = androidx.media3.common.Player.REPEAT_MODE_OFF

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this).build()
    }

    override fun onTerminate() {
        player.release()
        super.onTerminate()
    }
}
