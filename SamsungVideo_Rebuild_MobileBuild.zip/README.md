# Samsung Video Rebuild — proyecto inicial

Este repositorio contiene dos variantes Android del mismo reproductor:
- **Classic**: interfaz sobria inspirada en la biblioteca Samsung Video antigua.
- **Ultra**: interfaz oscura adaptada a teléfonos actuales.

## Compilar
1. Abrir esta carpeta en Android Studio (Hedgehog o superior).
2. Esperar la sincronización de Gradle.
3. En Build Variants elegir `classicDebug` o `ultraDebug`.
4. Ejecutar en un Samsung Galaxy S25 Ultra con Android 14/15+.

## Funciones implementadas en esta primera base
- Lectura de videos locales mediante MediaStore y permiso Android.
- Miniaturas, cuadrícula/lista, búsqueda y filtro por carpeta.
- Reproducción con controles Media3/ExoPlayer.
- Salto horizontal de 10 segundos y gestos verticales de volumen/brillo.
- Entrada a Picture-in-Picture al salir de la app.

## Pendiente antes de considerarla terminada
- Servicio MediaSession para reproducción en segundo plano con pantalla apagada.
- Navegación de carpetas avanzada y selección múltiple.
- Doble toque configurable 10/30 s, barra de gestos más pulida y pruebas en dispositivo.
- Iconos, tipografías, capturas y acabado visual fiel a las referencias originales.

**Importante:** esto es código fuente inicial, no un APK final ya compilado ni probado. Para instalarlo hay que compilar una variante desde Android Studio. No se presenta como clon oficial de Samsung.

## Compilar desde tu celular sin PC (GitHub Actions)
1. Crea una cuenta gratuita en https://github.com/ desde el navegador del celular.
2. Crea un repositorio nuevo y sube el contenido de este ZIP (incluida la carpeta oculta `.github`).
3. En el repositorio abre **Actions** y ejecuta **Build Samsung Video APKs** con **Run workflow**.
4. Cuando termine en verde, entra al trabajo y descarga el artefacto **Samsung-Video-APKs**. Dentro estarán los APK de depuración para instalar en tu S25 Ultra.

La compilación se realiza en servidores de GitHub; no requiere Android Studio en el teléfono. El APK resultante es de prueba/debug y aún no está publicado ni firmado para distribución.
