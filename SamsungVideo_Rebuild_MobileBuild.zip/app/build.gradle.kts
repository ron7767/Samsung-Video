plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ronal.samsungvideo"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.ronal.samsungvideo"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
    flavorDimensions += "edition"
    productFlavors {
        create("classic") { dimension = "edition"; applicationIdSuffix = ".classic"; resValue("string", "app_name", "Samsung Video Classic") }
        create("ultra") { dimension = "edition"; applicationIdSuffix = ".ultra"; resValue("string", "app_name", "Samsung Video Ultra") }
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
}
