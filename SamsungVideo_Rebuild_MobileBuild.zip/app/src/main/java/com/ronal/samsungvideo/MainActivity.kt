package com.ronal.samsungvideo

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val videos = mutableListOf<VideoItem>()
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private var grid = true
    private var classic = false
    private var query = ""
    private var folder = "Todos"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        classic = packageName.endsWith(".classic")
        window.statusBarColor = if (classic) 0xff263238.toInt() else 0xff101114.toInt()
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(if (classic) 0xffeeeeee.toInt() else 0xff101114.toInt()) }
        setContentView(root)
        if (hasPermission()) loadVideos() else requestPermission()
    }

    private fun hasPermission(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    }
    private fun requestPermission() {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        ActivityCompat.requestPermissions(this, arrayOf(p), 41)
    }
    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r,p,g); if (r == 41 && g.firstOrNull() == PackageManager.PERMISSION_GRANTED) loadVideos() else showPermissionMessage()
    }
    private fun showPermissionMessage() {
        root.removeAllViews()
        root.addView(TextView(this).apply { text="Permite el acceso a videos para mostrar tu biblioteca."; textSize=18f; setPadding(24,40,24,24) })
    }
    private fun loadVideos() {
        videos.clear()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION, MediaStore.Video.Media.DATE_ADDED, MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
        contentResolver.query(collection, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            val id=c.getColumnIndexOrThrow(MediaStore.Video.Media._ID); val name=c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val dur=c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION); val date=c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val bucket=c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            while(c.moveToNext()) { val vid=c.getLong(id); videos.add(VideoItem(vid,c.getString(name) ?: "Video",android.content.ContentUris.withAppendedId(collection,vid),c.getLong(dur),c.getLong(date),c.getString(bucket) ?: "Otros")) }
        }
        render()
    }
    private fun render() {
        root.removeAllViews()
        val dark = !classic; val fg = if(dark) 0xfff4f4f4.toInt() else 0xff202124.toInt()
        val header = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,14,18,8) }
        val top = LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply { text=if(classic) "Videos" else "Biblioteca"; textSize=26f; setTextColor(fg); layoutParams=LinearLayout.LayoutParams(0,-2,1f) })
        top.addView(makeButton(if(grid) "☷" else "▦") { grid=!grid; render() })
        header.addView(top)
        val search = EditText(this).apply { hint="Buscar videos"; setSingleLine(); setTextColor(fg); setHintTextColor(if(dark) 0xffaaaaaa.toInt() else 0xff666666.toInt()); setText(query); setBackgroundColor(if(dark) 0xff24262b.toInt() else 0xffdddddd.toInt()) }
        search.addTextChangedListener(SimpleWatcher { query=it; renderItemsOnly() })
        header.addView(search)
        val folders = videos.map{it.folder}.distinct().sorted()
        val spinner = Spinner(this)
        val opts = listOf("Todos") + folders
        spinner.adapter=ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opts)
        spinner.setSelection(opts.indexOf(folder).coerceAtLeast(0))
        spinner.onItemSelectedListener=object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, pos: Int, id: Long) { if(folder!=opts[pos]) { folder=opts[pos]; renderItemsOnly() } }
        }
        header.addView(spinner)
        root.addView(header)
        list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(12,4,12,24) }
        val scroll=ScrollView(this); scroll.addView(list); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        renderItemsOnly()
    }
    private fun renderItemsOnly() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val filtered=videos.filter { (folder=="Todos" || it.folder==folder) && it.name.contains(query,true) }
        if(filtered.isEmpty()) { list.addView(TextView(this).apply { text="No se encontraron videos"; textSize=16f; setPadding(16,30,16,16); setTextColor(if(classic) 0xff333333.toInt() else 0xffdddddd.toInt()) }); return }
        val dark=!classic
        if(grid) {
            var row: LinearLayout?=null
            filtered.forEachIndexed { index,v ->
                if(index%2==0) { row=LinearLayout(this); list.addView(row) }
                row!!.addView(videoTile(v,true), LinearLayout.LayoutParams(0,-2,1f))
            }
        } else filtered.forEach { list.addView(videoTile(it,false)) }
    }
    private fun videoTile(v: VideoItem, isGrid: Boolean): View {
        val dark=!classic; val fg=if(dark) 0xffeeeeee.toInt() else 0xff222222.toInt()
        val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(8,8,8,12); setBackgroundColor(if(dark) 0xff1e2025.toInt() else 0xfff7f7f7.toInt()); setOnClickListener { startActivity(Intent(this@MainActivity,PlayerActivity::class.java).apply { putExtra("uri",v.uri.toString()); putExtra("name",v.name) }) } }
        val thumb=ImageView(this).apply { scaleType=ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xff333333.toInt()); try { setImageBitmap(if(Build.VERSION.SDK_INT>=29) contentResolver.loadThumbnail(v.uri,android.util.Size(480,270),null) else MediaStore.Video.Thumbnails.getThumbnail(contentResolver,v.id,MediaStore.Video.Thumbnails.MINI_KIND,null)) } catch(_:Exception){} }
        card.addView(thumb, LinearLayout.LayoutParams(-1, if(isGrid) 116 else 92))
        val info=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(8,6,4,0) }
        info.addView(TextView(this).apply { text=v.name; textSize=14f; maxLines=2; setTextColor(fg) })
        info.addView(TextView(this).apply { text="${formatDuration(v.duration)}  •  ${SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(Date(v.date*1000))}"; textSize=11f; setTextColor(if(dark) 0xffaaaaaa.toInt() else 0xff666666.toInt()) })
        card.addView(info)
        val lp=LinearLayout.LayoutParams(if(isGrid) 0 else -1,-2); lp.setMargins(4,4,4,8)
        card.layoutParams=lp
        return card
    }
    private fun makeButton(label:String, action:()->Unit)=TextView(this).apply { text=label; textSize=24f; gravity=Gravity.CENTER; setPadding(16,6,16,6); setTextColor(if(classic) 0xff222222.toInt() else 0xffffffff.toInt()); setOnClickListener{action()} }
    private fun formatDuration(ms:Long):String { val s=ms/1000; return "%02d:%02d".format(s/60,s%60) }
}
