package com.ronal.samsungvideo

import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.*
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlin.math.abs

class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer?=null
    private lateinit var playerView: PlayerView
    private var downX=0f; private var downY=0f; private var startPos=0L
    private var seeking=false
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility=(View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        playerView=PlayerView(this).apply { useController=true; controllerShowTimeoutMs=3500; setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING) }
        setContentView(FrameLayout(this).apply { addView(playerView,FrameLayout.LayoutParams(-1,-1)) })
        val uri=Uri.parse(intent.getStringExtra("uri") ?: return)
        player=ExoPlayer.Builder(this).build().also { p -> playerView.player=p; p.setMediaItem(MediaItem.fromUri(uri)); p.prepare(); p.playWhenReady=true }
        playerView.setOnTouchListener { _,e ->
            when(e.action) {
                MotionEvent.ACTION_DOWN -> { downX=e.x; downY=e.y; startPos=player?.currentPosition ?: 0L; seeking=false; true }
                MotionEvent.ACTION_UP -> {
                    val dx=e.x-downX; val dy=e.y-downY
                    if(abs(dx)>70 && abs(dx)>abs(dy)) { val delta=if(dx>0) 10_000L else -10_000L; player?.seekTo(((player?.currentPosition ?: 0L)+delta).coerceAtLeast(0)); seeking=true }
                    else if(abs(dy)>90 && abs(dy)>abs(dx)) { val fraction=downX/playerView.width; val audio= getSystemService(AUDIO_SERVICE) as android.media.AudioManager
                        if(fraction<0.5f) { val max=audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC); val cur=audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC); audio.setStreamVolume(android.media.AudioManager.STREAM_MUSIC,(cur + if(dy<0) 1 else -1).coerceIn(0,max),0) }
                        else { val lp=window.attributes; lp.screenBrightness=(lp.screenBrightness + if(dy<0) 0.08f else -0.08f).coerceIn(0.05f,1f); window.attributes=lp }
                    }
                    true
                }
                else -> true
            }
        }
    }
    override fun onUserLeaveHint() {
        if(Build.VERSION.SDK_INT>=26 && packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            if(Build.VERSION.SDK_INT>=26) enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16,9)).build())
        }
    }
    override fun onStop(){ super.onStop(); if(!isInPictureInPictureMode) { player?.release(); player=null } }
    override fun onDestroy(){ player?.release(); player=null; super.onDestroy() }
}
