package com.ronal.samsungvideo

import android.net.Uri

data class VideoItem(val id: Long, val name: String, val uri: Uri, val duration: Long, val date: Long, val folder: String)
